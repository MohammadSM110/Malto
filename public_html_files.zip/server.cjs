var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_path = __toESM(require("path"), 1);
var import_crypto = __toESM(require("crypto"), 1);
var import_config = require("dotenv/config");
var import_vite = require("vite");
var ADMIN_SECRET = process.env.ADMIN_SESSION_SECRET || "maalto_admin_jwt_secret_salt_92817";
function verifyStringSecure(a, b) {
  if (typeof a !== "string" || typeof b !== "string") return false;
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) return false;
  return import_crypto.default.timingSafeEqual(bufA, bufB);
}
function createAdminToken(username) {
  const payload = {
    username,
    createdAt: Date.now(),
    exp: Date.now() + 24 * 60 * 60 * 1e3,
    // 24 hours validity
    nonce: import_crypto.default.randomBytes(16).toString("hex")
  };
  const data = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const signature = import_crypto.default.createHmac("sha256", ADMIN_SECRET).update(data).digest("base64url");
  return `${data}.${signature}`;
}
function verifyAdminToken(token) {
  if (!token || typeof token !== "string") return { valid: false, error: "\u062A\u0648\u06A9\u0646 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A" };
  const parts = token.split(".");
  if (parts.length !== 2) return { valid: false, error: "\u0641\u0631\u0645\u062A \u062A\u0648\u06A9\u0646 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A" };
  const [data, signature] = parts;
  const expectedSig = import_crypto.default.createHmac("sha256", ADMIN_SECRET).update(data).digest("base64url");
  const bufSig = Buffer.from(signature);
  const bufExp = Buffer.from(expectedSig);
  if (bufSig.length !== bufExp.length || !import_crypto.default.timingSafeEqual(bufSig, bufExp)) {
    return { valid: false, error: "\u0627\u0645\u0636\u0627\u06CC \u0646\u0634\u0633\u062A \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A" };
  }
  try {
    const payload = JSON.parse(Buffer.from(data, "base64url").toString("utf8"));
    if (!payload.exp || Date.now() > payload.exp) {
      return { valid: false, error: "\u0646\u0634\u0633\u062A \u0645\u062F\u06CC\u0631 \u0645\u0646\u0642\u0636\u06CC \u0634\u062F\u0647 \u0627\u0633\u062A" };
    }
    return { valid: true, username: payload.username };
  } catch {
    return { valid: false, error: "\u067E\u0631\u062F\u0627\u0632\u0634 \u062A\u0648\u06A9\u0646 \u0628\u0627 \u062E\u0637\u0627 \u0645\u0648\u0627\u062C\u0647 \u0634\u062F" };
  }
}
async function startServer() {
  const app = (0, import_express.default)();
  const PORT = 3e3;
  app.use(import_express.default.json());
  app.enable("trust proxy");
  app.use((req, res, next) => {
    if (process.env.NODE_ENV === "production" && req.headers["x-forwarded-proto"] && req.headers["x-forwarded-proto"] !== "https") {
      return res.redirect(301, `https://${req.headers.host}${req.url}`);
    }
    next();
  });
  app.get("/api/health", (req, res) => {
    res.json({
      status: "ok",
      app: "Maalto",
      version: "1.0.0",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      services: {
        firestore: "connected",
        auth: "configured",
        environment: process.env.NODE_ENV || "development"
      }
    });
  });
  app.get("/api/status", (req, res) => {
    res.json({
      online: true,
      platform: "Google Cloud Run / AI Studio",
      appName: "Maalto | \u0645\u0627\u0644\u062A\u0648",
      mode: process.env.NODE_ENV === "production" ? "production" : "development"
    });
  });
  app.post("/api/admin/login", (req, res) => {
    const { username, password } = req.body || {};
    if (!username || !password) {
      return res.status(400).json({ success: false, error: "\u0646\u0627\u0645 \u06A9\u0627\u0631\u0628\u0631\u06CC \u0648 \u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A." });
    }
    const expectedUser = (process.env.ADMIN_USERNAME || "admin").trim();
    const expectedPass = process.env.ADMIN_PASSWORD || "MaaltoAdmin#2026!";
    const userMatch = verifyStringSecure(String(username).trim(), expectedUser);
    const passMatch = verifyStringSecure(String(password), expectedPass);
    if (userMatch && passMatch) {
      const token = createAdminToken(expectedUser);
      return res.json({
        success: true,
        token,
        username: expectedUser,
        expiresIn: 86400
      });
    } else {
      return res.status(401).json({
        success: false,
        error: "\u0646\u0627\u0645 \u06A9\u0627\u0631\u0628\u0631\u06CC \u06CC\u0627 \u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0627\u0634\u062A\u0628\u0627\u0647 \u0627\u0633\u062A."
      });
    }
  });
  app.post("/api/admin/verify", (req, res) => {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.startsWith("Bearer ") ? authHeader.slice(7) : req.body?.token;
    const result = verifyAdminToken(token);
    if (result.valid) {
      return res.json({ valid: true, username: result.username });
    } else {
      return res.status(401).json({ valid: false, error: result.error });
    }
  });
  app.post("/api/admin/logout", (_req, res) => {
    return res.json({ success: true });
  });
  if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Maalto server running on http://0.0.0.0:${PORT}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
