var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// server.ts
var import_express = __toESM(require("express"), 1);
var import_http = __toESM(require("http"), 1);
var import_path = __toESM(require("path"), 1);
var import_crypto = __toESM(require("crypto"), 1);
var import_config = require("dotenv/config");
var import_vite = require("vite");
var ADMIN_SECRET = process.env.ADMIN_SESSION_SECRET || "e9b4c7d2f810a546e8b1c7d2e9f035418b7a9c2d1e6f803b5a7c9d1e2f4a8b0c";
var ADMIN_USERNAME = (process.env.ADMIN_USERNAME || "admin").trim();
var ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "MaaltoAdmin#2026!";
var MAX_FAILED_ATTEMPTS = 5;
var LOCKOUT_DURATION_MS = 5 * 60 * 1e3;
var loginAttempts = /* @__PURE__ */ new Map();
function getClientIp(req) {
  const forwarded = req.headers["x-forwarded-for"];
  if (typeof forwarded === "string") {
    return forwarded.split(",")[0].trim();
  }
  return req.socket.remoteAddress || "unknown";
}
function verifyStringSecure(a, b) {
  if (typeof a !== "string" || typeof b !== "string") return false;
  const hashA = import_crypto.default.createHash("sha256").update(a).digest();
  const hashB = import_crypto.default.createHash("sha256").update(b).digest();
  return import_crypto.default.timingSafeEqual(hashA, hashB);
}
function createAdminToken(username) {
  const payload = {
    username,
    createdAt: Date.now(),
    exp: Date.now() + 24 * 60 * 60 * 1e3,
    // 24 hours validity
    nonce: import_crypto.default.randomBytes(16).toString("hex")
  };
  const data = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const signature = import_crypto.default.createHmac("sha256", ADMIN_SECRET).update(data).digest("base64url");
  return `${data}.${signature}`;
}
function verifyAdminToken(token) {
  if (!token || typeof token !== "string") return { valid: false, error: "\u062A\u0648\u06A9\u0646 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A" };
  const parts = token.split(".");
  if (parts.length !== 2) return { valid: false, error: "\u0641\u0631\u0645\u062A \u062A\u0648\u06A9\u0646 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A" };
  const [data, signature] = parts;
  const expectedSig = import_crypto.default.createHmac("sha256", ADMIN_SECRET).update(data).digest("base64url");
  const bufSig = import_crypto.default.createHash("sha256").update(signature).digest();
  const bufExp = import_crypto.default.createHash("sha256").update(expectedSig).digest();
  if (!import_crypto.default.timingSafeEqual(bufSig, bufExp)) {
    return { valid: false, error: "\u0627\u0645\u0636\u0627\u06CC \u0646\u0634\u0633\u062A \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A" };
  }
  try {
    const payload = JSON.parse(Buffer.from(data, "base64url").toString("utf8"));
    if (!payload.exp || Date.now() > payload.exp) {
      return { valid: false, error: "\u0646\u0634\u0633\u062A \u0645\u062F\u06CC\u0631 \u0645\u0646\u0642\u0636\u06CC \u0634\u062F\u0647 \u0627\u0633\u062A" };
    }
    return { valid: true, username: payload.username };
  } catch {
    return { valid: false, error: "\u067E\u0631\u062F\u0627\u0632\u0634 \u062A\u0648\u06A9\u0646 \u0628\u0627 \u062E\u0637\u0627 \u0645\u0648\u0627\u062C\u0647 \u0634\u062F" };
  }
}
async function startServer() {
  const app = (0, import_express.default)();
  const server = import_http.default.createServer(app);
  const PORT = 3e3;
  app.use((req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, PATCH");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With, Accept");
    res.setHeader("Access-Control-Max-Age", "86400");
    if (req.method === "OPTIONS") {
      return res.sendStatus(204);
    }
    next();
  });
  app.use(import_express.default.json());
  app.use((req, res, next) => {
    const start = Date.now();
    const url = req.originalUrl || req.url;
    if (url.startsWith("/api")) {
      res.on("finish", () => {
        const duration = Date.now() - start;
        console.log(`[Backend Log] ${req.method} ${url} -> ${res.statusCode} (${duration}ms)`);
      });
    }
    next();
  });
  app.enable("trust proxy");
  app.use((req, res, next) => {
    if (process.env.NODE_ENV === "production" && req.headers["x-forwarded-proto"] && req.headers["x-forwarded-proto"] !== "https") {
      return res.redirect(301, `https://${req.headers.host}${req.url}`);
    }
    next();
  });
  app.get("/api/health", (_req, res) => {
    res.json({
      status: "ok",
      app: "Maalto",
      version: "1.0.0",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      services: {
        firestore: "connected",
        auth: "configured",
        environment: process.env.NODE_ENV || "development",
        websockets: "enabled"
      }
    });
  });
  app.get("/api/status", (_req, res) => {
    res.json({
      online: true,
      platform: "Google Cloud Run / AI Studio",
      appName: "Maalto | \u0645\u0627\u0644\u062A\u0648",
      mode: process.env.NODE_ENV === "production" ? "production" : "development"
    });
  });
  app.get("/api/fonts/css", async (req, res) => {
    try {
      const fontUrl = "https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&family=Vazirmatn:wght@200;300;400;500;600;700;800;900&display=swap";
      const fontRes = await fetch(fontUrl, {
        headers: {
          "User-Agent": req.headers["user-agent"] || "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
          Accept: "text/css,*/*;q=0.1"
        }
      });
      if (!fontRes.ok) {
        return res.status(fontRes.status).send("");
      }
      const css = await fontRes.text();
      res.setHeader("Content-Type", "text/css; charset=utf-8");
      res.setHeader("Cache-Control", "public, max-age=86400, stale-while-revalidate=604800");
      res.setHeader("Access-Control-Allow-Origin", "*");
      return res.send(css);
    } catch (err) {
      console.warn("[Backend Log] Font proxy fetch notice:", err?.message || err);
      return res.status(500).send("");
    }
  });
  app.post("/api/admin/login", (req, res) => {
    const clientIp = getClientIp(req);
    const attemptRecord = loginAttempts.get(clientIp);
    if (attemptRecord && attemptRecord.lockedUntil > Date.now()) {
      const remainingMinutes = Math.ceil((attemptRecord.lockedUntil - Date.now()) / 6e4);
      return res.status(429).json({
        success: false,
        error: `\u062A\u0639\u062F\u0627\u062F \u062A\u0644\u0627\u0634\u200C\u0647\u0627\u06CC \u0646\u0627\u0645\u0648\u0641\u0642 \u0628\u06CC\u0634 \u0627\u0632 \u062D\u062F \u0645\u062C\u0627\u0632 \u0627\u0633\u062A. \u0644\u0637\u0641\u0627\u064B ${remainingMinutes} \u062F\u0642\u06CC\u0642\u0647 \u062F\u06CC\u06AF\u0631 \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F.`
      });
    }
    const { username, password } = req.body || {};
    if (!username || !password) {
      return res.status(400).json({ success: false, error: "\u0646\u0627\u0645 \u06A9\u0627\u0631\u0628\u0631\u06CC \u0648 \u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0627\u0644\u0632\u0627\u0645\u06CC \u0627\u0633\u062A." });
    }
    const userMatch = verifyStringSecure(String(username).trim(), ADMIN_USERNAME);
    const passMatch = verifyStringSecure(String(password), ADMIN_PASSWORD);
    if (userMatch && passMatch) {
      loginAttempts.delete(clientIp);
      const token = createAdminToken(ADMIN_USERNAME);
      return res.json({
        success: true,
        token,
        username: ADMIN_USERNAME,
        expiresIn: 86400
      });
    } else {
      const currentAttempts = (attemptRecord ? attemptRecord.attempts : 0) + 1;
      const isLocked = currentAttempts >= MAX_FAILED_ATTEMPTS;
      const lockedUntil = isLocked ? Date.now() + LOCKOUT_DURATION_MS : 0;
      loginAttempts.set(clientIp, { attempts: currentAttempts, lockedUntil });
      if (isLocked) {
        return res.status(429).json({
          success: false,
          error: "\u062A\u0639\u062F\u0627\u062F \u062F\u0641\u0639\u0627\u062A \u0648\u0631\u0648\u062F \u0627\u0634\u062A\u0628\u0627\u0647 \u0628\u06CC\u0634 \u0627\u0632 \u062D\u062F \u0645\u062C\u0627\u0632 (\u06F5 \u0628\u0627\u0631) \u0628\u0648\u062F. \u062F\u0633\u062A\u0631\u0633\u06CC \u0628\u0631\u0627\u06CC \u06F5 \u062F\u0642\u06CC\u0642\u0647 \u0645\u0633\u062F\u0648\u062F \u0634\u062F."
        });
      }
      return res.status(401).json({
        success: false,
        error: "\u0646\u0627\u0645 \u06A9\u0627\u0631\u0628\u0631\u06CC \u06CC\u0627 \u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0627\u0634\u062A\u0628\u0627\u0647 \u0627\u0633\u062A."
      });
    }
  });
  app.post("/api/admin/verify", (req, res) => {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.startsWith("Bearer ") ? authHeader.slice(7) : req.body?.token;
    const result = verifyAdminToken(token);
    if (result.valid) {
      return res.json({ valid: true, username: result.username });
    } else {
      return res.status(401).json({ valid: false, error: result.error });
    }
  });
  app.post("/api/admin/logout", (_req, res) => {
    return res.json({ success: true });
  });
  let vite = null;
  if (process.env.NODE_ENV !== "production") {
    vite = await (0, import_vite.createServer)({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR === "true" ? false : { server }
      },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(import_path.default.join(distPath, "index.html"));
    });
  }
  server.on("upgrade", (req, socket, head) => {
    const url = req.url || "/";
    if (vite && vite.ws) {
      return;
    }
    if (process.env.DISABLE_HMR === "true" || !vite) {
      if (!socket.destroyed) {
        socket.write("HTTP/1.1 404 Not Found\r\nConnection: close\r\n\r\n");
        socket.destroy();
      }
    }
  });
  server.on("clientError", (err, socket) => {
    if (err?.code === "ECONNRESET" || !socket.writable) {
      return;
    }
    socket.end("HTTP/1.1 400 Bad Request\r\n\r\n");
  });
  server.listen(PORT, "0.0.0.0", () => {
    console.log(`[Backend Log] Maalto server running on http://0.0.0.0:${PORT}`);
    console.log(`[Backend Log] Upgrade listeners on server: ${server.listenerCount("upgrade")}`);
  });
}
startServer();
//# sourceMappingURL=server.cjs.map
